//Hent inn modulen
const express = require('express')

//starte en express applikasjon, og lagre den i app
const app = express()

const hbs = require('hbs')

//Callback funksjon for noen åpner root mappen på web-serveren vår
function rootRoute(request, response) {
    response.render('index', {
        title: "Velkommen!",
        author: "Hans Hansen",
        interests: ["cars","piano","dance"]
    })
}
//Sende callback funksjonen inn i Express, knyttet til root-mappen ved hjelp av tom streng ''
app.get('', rootRoute)

app.listen(3000, () => {
    console.log('Server is up on port 3000')
})

function aboutRoute(request, response) {
    response.send("About")
}
app.get('/about', aboutRoute)


const path = require('path')
const publicDirectoryPath = path.join(__dirname, "./public")
app.use(express.static(publicDirectoryPath))

app.set('view engine', 'hbs')

const viewsPath = path.join(__dirname, 'views/pages')
app.set('views', viewsPath)

const partialsPath = path.join(__dirname, 'views/partials')
hbs.registerPartials(partialsPath)